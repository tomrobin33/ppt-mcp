# flake8: noqa
from .applicative import Applicative
from .functor import Functor
from .monoid import Monoid
from .monad import Monad
