Unit = ()


def indent(level, size=2):
    """Return indentation."""
    return ' ' * level * size
